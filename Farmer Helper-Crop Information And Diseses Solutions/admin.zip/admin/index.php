<?php include('partials/dash-header.php');?>
    <div class="content">
        <div class="header">Admin Dashboard</div>
        <div class="dashboard">
            <div class="card">
                <h3>Total Farmers</h3>
                <p>150</p>
            </div>
            <div class="card">
                <h3>Total Crops</h3>
                <p>35</p>
            </div>
            <div class="card">
                <h3>Pending Queries</h3>
                <p>12</p>
            </div>
        </div>
    </div>
</body>
</html>
